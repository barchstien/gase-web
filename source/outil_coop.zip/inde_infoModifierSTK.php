<!DOCTYPE html>
<html>
    <head>
		<!-- En-tête de la page -->
        <meta charset="utf-8" />
        <title>STOCKS</title>
    </head>

    <body>
		<div class="menu">
			<?php include 'inde_menu.php'; ?>
		</div>
		
		<div style="text-align:center">
			Les stocks ont ete mis a jour dans la base de donnees.
		</div>
	</body>
</html>





